from fastapi import APIRouter, Depends, HTTPException
from typing import List
from app.schemas.models import Model, ModelCreate
from app.services.supabase_service import SupabaseService
from app.utils.auth import get_current_user, User

router = APIRouter()

@router.get("/models", response_model=List[Model])
async def read_models(current_user: User = Depends(get_current_user)):
    supabase_service = SupabaseService()
    models = supabase_service.get_models(current_user.id)
    if not models:
        raise HTTPException(status_code=404, detail="Models not found")
    return models

@router.post("/models", response_model=Model)
async def create_model(model: ModelCreate, current_user: User = Depends(get_current_user)):
    supabase_service = SupabaseService()
    created_model = supabase_service.create_model(model, current_user.id)
    if not created_model:
        raise HTTPException(status_code=400, detail="Error creating model")
    return created_model

@router.delete("/models/{model_id}")
async def delete_model(model_id: int, current_user: User = Depends(get_current_user)):
    supabase_service = SupabaseService()
    success = supabase_service.delete_model(model_id, current_user.id)
    if not success:
        raise HTTPException(status_code=400, detail="Error deleting model")
    return {"message": "Model deleted successfully"}
