from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    secret_key: str
    debug: bool
    allowed_hosts: str
    cors_allowed_origins: str
    supabase_url: str
    supabase_key: str
    supabase_db_name: str
    supabase_db_user: str
    supabase_db_password: str
    supabase_db_host: str
    ubiops_api_token: str
    algorithm: str = 'HS256'

    class Config:
        env_file = ".env"


settings = Settings()
