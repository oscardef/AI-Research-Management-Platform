from pydantic import BaseModel
from typing import List, Optional

class ModelBase(BaseModel):
    name: str
    description: Optional[str] = None
    version: str
    performance_metrics: Optional[str] = None
    file_url: str

class ModelCreate(ModelBase):
    pass

class Model(ModelBase):
    id: int
    owner_id: str
    collaborators: List[str] = []
    created_at: Optional[str] = None

    class Config:
        from_attributes = True  # Update here
