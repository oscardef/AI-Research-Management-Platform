from app.utils.config import settings
from supabase import create_client, Client
from app.schemas.models import ModelCreate

class SupabaseService:
    def __init__(self):
        self.client = create_client(settings.SUPABASE_URL, settings.SUPABASE_KEY)

    def get_models(self, user_id: str):
        response = self.client.from_("models").select("*").contains("collaborators", [user_id]).execute()
        return response.data

    def create_model(self, model: ModelCreate, user_id: str):
        data = {
            "name": model.name,
            "description": model.description,
            "version": model.version,
            "performance_metrics": model.performance_metrics,
            "file_url": model.file_url,
            "owner_id": user_id,
            "collaborators": [user_id]
        }
        response = self.client.from_("models").insert(data).execute()
        return response.data[0] if response.data else None

    def delete_model(self, model_id: int, user_id: str):
        response = self.client.from_("models").delete().eq("id", model_id).eq("owner_id", user_id).execute()
        return response.status_code == 204
