"""
The file containing the deployment code needs to be called 'deployment.py' and should contain a 'Deployment'
class a 'request' method.
"""

import keras
from keras import layers

from PIL import Image
import math

import numpy as np

class Deployment:

	def __init__(self, base_directory, context):
		"""
		Initialisation method for the deployment. Any code inside this method will execute when the deployment starts up.
		It can for example be used for loading modules that have to be stored in memory or setting up connections.
		"""
		
		self.workshop_model = keras.models.load_model('workshop_model.h5')
		
		self.workshop_model.summary()

		print("Initialising deployment")


	def request(self, data):
		"""
		Method for deployment requests, called separately for each individual request.
		"""
		
		classNames = ['cat', 'crow', 'goose', 'moth', 'mouse']
		
		img = Image.open(data["image"]).convert('RGB')
		
		w, h = img.size
		
		resizeFactor = 256 / min(w, h)
		
		newImg = img.resize((math.ceil(w * resizeFactor), math.ceil(h * resizeFactor)))
		
		l = (newImg.size[0] - 256) / 2
		r = newImg.size[0] - l
		u = (newImg.size[1] - 256) / 2
		d = newImg.size[1] - u
		newImg = newImg.crop((l,u,r,d))
		imgArray = np.array(newImg) / 255
		imgArray = np.reshape(imgArray, (1, 256, 256, 3))

		# The Prediction
		odds = self.workshop_model.predict(imgArray)

		print()
		for animalID in range(len(classNames)):
			oddNum = odds[0][animalID] * 100
			if (oddNum >= 10):
				print(classNames[animalID] + '\t' + '{0:.3f}'.format(oddNum) + '%')
			else:
				print(classNames[animalID] + '\t ' + '{0:.3f}'.format(oddNum) + '%')
		
		# here we set our output parameters in the form of a json
		return {"judgement": "I think this is a... " + classNames[np.argmax(odds)] + "?"}
